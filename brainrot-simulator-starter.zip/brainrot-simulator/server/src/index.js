import 'dotenv/config';
import express from 'express';
import Database from 'better-sqlite3';
import TelegramBot from 'node-telegram-bot-api';

const app = express();
app.use(express.json({limit:'32kb'}));
const db = new Database('brainrot.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    telegram_id TEXT PRIMARY KEY,
    coins INTEGER NOT NULL DEFAULT 1000,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS inventory (
    telegram_id TEXT NOT NULL,
    brainrot_name TEXT NOT NULL,
    rarity TEXT NOT NULL,
    emoji TEXT NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (telegram_id, brainrot_name)
  );
  CREATE TABLE IF NOT EXISTS openings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id TEXT NOT NULL,
    case_id TEXT NOT NULL,
    brainrot_name TEXT NOT NULL,
    rarity TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);
const CASES = {
  starter: {price:100, pool:[
    {name:'Noobini Pizzanini',emoji:'🍕',rarity:'Common',weight:48},
    {name:'Lirili Larila',emoji:'🌵',rarity:'Common',weight:48},
    {name:'Fluriflura',emoji:'🌸',rarity:'Rare',weight:27},
    {name:'Trippi Troppi',emoji:'🦐',rarity:'Rare',weight:27},
    {name:'Cappuccino Assassino',emoji:'☕',rarity:'Epic',weight:15},
    {name:'Tralalero Tralala',emoji:'🦈',rarity:'Legendary',weight:7}
  ]},
  meme: {price:350, pool:[
    {name:'Tim Cheese',emoji:'🧀',rarity:'Common',weight:48},
    {name:'Pipi Avocado',emoji:'🥑',rarity:'Rare',weight:27},
    {name:'Brr Brr Patapim',emoji:'🌳',rarity:'Epic',weight:15},
    {name:'Bombardiro Crocodilo',emoji:'🐊',rarity:'Legendary',weight:7},
    {name:'Ballerina Cappuccina',emoji:'🩰',rarity:'Mythic',weight:2.5}
  ]}
};
const getUser = db.prepare('SELECT * FROM users WHERE telegram_id=?');
const ensureUser = db.prepare('INSERT OR IGNORE INTO users(telegram_id) VALUES(?)');
const addInventory = db.prepare(`INSERT INTO inventory(telegram_id,brainrot_name,rarity,emoji,quantity)
 VALUES(?,?,?,?,1) ON CONFLICT(telegram_id,brainrot_name) DO UPDATE SET quantity=quantity+1`);
function choose(pool){
  const total=pool.reduce((s,x)=>s+x.weight,0);let n=Math.random()*total;
  for(const item of pool){n-=item.weight;if(n<=0)return item}
  return pool.at(-1);
}
// NOTE: In production, never accept a claimed Telegram ID from arbitrary web clients.
// Verify Telegram Web App initData HMAC server-side before exposing user-specific endpoints.
app.get('/api/health',(_req,res)=>res.json({ok:true,mode:'virtual-coins-demo'}));
app.get('/api/cases',(_req,res)=>res.json(Object.entries(CASES).map(([id,c])=>({id,price:c.price,odds:c.pool.map(({name,emoji,rarity,weight})=>({name,emoji,rarity,weight}))}))));
app.post('/api/dev/open', (req,res)=>{
  // Local integration placeholder only. Disable this route in production and replace
  // with verified Telegram Web App authentication and server-side rate limiting.
  const {telegramId,caseId}=req.body||{};
  if(!telegramId || !/^\d{1,20}$/.test(String(telegramId))) return res.status(400).json({error:'invalid_demo_user'});
  const c=CASES[caseId];if(!c)return res.status(404).json({error:'unknown_case'});
  const tx=db.transaction(()=>{
    ensureUser.run(String(telegramId));const user=getUser.get(String(telegramId));
    if(user.coins<c.price)throw new Error('not_enough_coins');
    const drop=choose(c.pool);
    db.prepare('UPDATE users SET coins=coins-? WHERE telegram_id=?').run(c.price,String(telegramId));
    addInventory.run(String(telegramId),drop.name,drop.rarity,drop.emoji);
    db.prepare('INSERT INTO openings(telegram_id,case_id,brainrot_name,rarity) VALUES(?,?,?,?)').run(String(telegramId),caseId,drop.name,drop.rarity);
    return {drop,coins:user.coins-c.price};
  });
  try{res.json(tx())}catch(e){res.status(e.message==='not_enough_coins'?400:500).json({error:e.message})}
});
app.get('/api/dev/profile/:telegramId',(req,res)=>{
  const id=String(req.params.telegramId);
  if(!/^\d{1,20}$/.test(id))return res.status(400).json({error:'invalid_demo_user'});
  ensureUser.run(id);
  res.json({user:getUser.get(id),inventory:db.prepare('SELECT brainrot_name AS name,rarity,emoji,quantity FROM inventory WHERE telegram_id=? ORDER BY quantity DESC').all(id)});
});
const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`Brainrot API listening on :${port}`));

if(process.env.BOT_TOKEN && process.env.BOT_TOKEN!=='put_your_telegram_bot_token_here'){
  const bot=new TelegramBot(process.env.BOT_TOKEN,{polling:true});
  const webUrl=process.env.WEB_APP_URL;
  bot.onText(/\/start/,async msg=>{
    const opts={reply_markup:{keyboard:[[{text:'🎮 Открыть симулятор',web_app:{url:webUrl||'https://example.com'}}],[{text:'🪙 Мой баланс',callback_data:'balance'}]],resize_keyboard:true}};
    await bot.sendMessage(msg.chat.id,
      `🧠 Добро пожаловать в Brainrot Lab!\\n\\nСобирай брейнротов в демо-симуляторе. Здесь используются только виртуальные монеты.`,opts);
  });
  bot.onText(/\/balance/,msg=>{
    ensureUser.run(String(msg.from.id));
    const user=getUser.get(String(msg.from.id));
    bot.sendMessage(msg.chat.id,`🪙 Баланс: ${user.coins.toLocaleString('ru-RU')} виртуальных монет`);
  });
  bot.onText(/\/collection/,msg=>{
    const rows=db.prepare('SELECT brainrot_name,quantity,rarity FROM inventory WHERE telegram_id=? ORDER BY quantity DESC').all(String(msg.from.id));
    bot.sendMessage(msg.chat.id,rows.length?`🧠 Твоя коллекция:\\n${rows.map(x=>`• ${x.brainrot_name} ×${x.quantity} (${x.rarity})`).join('\\n')}`:'Коллекция пока пуста — открой симулятор командой /start.');
  });
  bot.onText(/\/help/,msg=>bot.sendMessage(msg.chat.id,'Команды:\\n/start — открыть меню\\n/balance — баланс\\n/collection — коллекция\\n/help — помощь'));
  console.log('Telegram bot polling started');
}
