# Brainrot Simulator — starter project

Demo-only case-opening simulator inspired by Roblox Steal a Brainrot. Uses virtual coins only.

## Included
- Responsive web frontend (HTML/CSS/JS), no build step required.
- Case opening with weighted drops, coin balance, collection, daily reward.
- Node.js + Express API starter and Telegram bot starter.
- SQLite persistence on the server.

## Run the website demo
Open `web/index.html` in a browser. This runs locally in demo mode using browser localStorage.

## Run the API + Telegram bot
Requires Node.js 20+.

1. `cd server`
2. `npm install`
3. Copy `.env.example` to `.env`
4. Put your Telegram bot token in `.env` (create a bot with BotFather).
5. `npm start`

The API runs on port 3000. Set `WEB_APP_URL` to your deployed website URL to enable the Telegram Web App button.
The included frontend runs standalone in local demo mode; connect it to the API before deploying a multi-user version.

## Important before public launch
- Configure HTTPS and host the API behind a reverse proxy.
- Implement Telegram Web App `initData` verification on the server before trusting Telegram identities.
- Keep case odds visible and validate all rewards server-side.
- Use only virtual coins in this starter. No deposits, withdrawals, or real-money wagering.
- This is a fan-made project, not affiliated with or endorsed by Roblox or the creators of Steal a Brainrot. Use authorized assets only.
