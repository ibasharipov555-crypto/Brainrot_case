const rarities = {
  Common:{color:"#a3a3b2",weight:48},
  Rare:{color:"#5ba8ff",weight:27},
  Epic:{color:"#bb83ff",weight:15},
  Legendary:{color:"#ffbd59",weight:7},
  Mythic:{color:"#ff668d",weight:2.5},
  Secret:{color:"#61ead5",weight:.5}
};
const brainrots = [
  {name:"Noobini Pizzanini",emoji:"🍕",rarity:"Common"},
  {name:"Lirili Larila",emoji:"🌵",rarity:"Common"},
  {name:"Tim Cheese",emoji:"🧀",rarity:"Common"},
  {name:"Fluriflura",emoji:"🌸",rarity:"Rare"},
  {name:"Trippi Troppi",emoji:"🦐",rarity:"Rare"},
  {name:"Pipi Avocado",emoji:"🥑",rarity:"Rare"},
  {name:"Cappuccino Assassino",emoji:"☕",rarity:"Epic"},
  {name:"Brr Brr Patapim",emoji:"🌳",rarity:"Epic"},
  {name:"Tralalero Tralala",emoji:"🦈",rarity:"Legendary"},
  {name:"Bombardiro Crocodilo",emoji:"🐊",rarity:"Legendary"},
  {name:"Ballerina Cappuccina",emoji:"🩰",rarity:"Mythic"},
  {name:"Secret Lucky Brainrot",emoji:"👾",rarity:"Secret"}
];
const cases = [
 {id:"starter",name:"Starter Case",desc:"Для начала большой коллекции",price:100,emoji:"📦",color:"linear-gradient(135deg,#29384b,#202033)",pool:brainrots.slice(0,6)},
 {id:"meme",name:"Meme Madness",desc:"Больше эпических и легендарных",price:350,emoji:"🎭",color:"linear-gradient(135deg,#47305d,#202033)",pool:brainrots.slice(2,10)},
 {id:"secret",name:"Secret Vault",desc:"Охота за ультраредкими",price:900,emoji:"🔮",color:"linear-gradient(135deg,#174e50,#25223f)",pool:brainrots.slice(5)}
];
const $=s=>document.querySelector(s);
let state = JSON.parse(localStorage.getItem("brainrot-demo-v1")||"null") || {coins:1000,inventory:{},history:[],daily:null};
let selectedCase=cases[0],busy=false;
function save(){localStorage.setItem("brainrot-demo-v1",JSON.stringify(state));renderBalance();renderInventory()}
function fmt(n){return n.toLocaleString("ru-RU")}
function renderBalance(){$("#balance").textContent=fmt(state.coins)}
function renderCases(){
 $("#case-grid").innerHTML=cases.map(c=>`<article class="case-card"><div class="case-visual" style="background:${c.color}"><span>${c.emoji}</span></div><h3>${c.name}</h3><p>${c.desc}</p><div class="case-bottom"><span class="price">🪙 ${fmt(c.price)}</span><button class="primary" data-case="${c.id}">Открыть ↗</button></div></article>`).join("");
 document.querySelectorAll("[data-case]").forEach(b=>b.addEventListener("click",()=>selectCase(cases.find(c=>c.id===b.dataset.case))));
}
function renderInventory(){
 const entries=Object.entries(state.inventory).filter(([,v])=>v.count>0);
 $("#collection-count").textContent=`${entries.reduce((a,[,v])=>a+v.count,0)} предметов`;
 $("#inventory").innerHTML=entries.length?entries.map(([name,v])=>`<article class="item" style="border-bottom:2px solid ${rarities[v.rarity]?.color||"#888"}"><span class="qty">×${v.count}</span><div class="emoji">${v.emoji}</div><h4>${name}</h4><small style="color:${rarities[v.rarity]?.color}">${v.rarity}</small></article>`).join(""):`<div class="empty">Коллекция пока пуста. Открой первый кейс, чтобы найти своего брейнрота! 🧠</div>`;
}
function selectCase(c){
 selectedCase=c;$("#opener").classList.remove("hidden");$("#opening-title").textContent=c.name;$("#open-price").textContent=fmt(c.price);$("#result").textContent="Готов к открытию?";$("#odds").classList.add("hidden");$("#opener").scrollIntoView({behavior:"smooth",block:"center"});makeStrip(c);
}
function makeStrip(c){
 const list=[];for(let i=0;i<18;i++)list.push(c.pool[Math.floor(Math.random()*c.pool.length)]);
 $("#roulette").style.transition="none";$("#roulette").style.transform="translateX(0)";
 $("#roulette").innerHTML=list.map(b=>`<div class="tile" style="border-bottom:2px solid ${rarities[b.rarity].color}"><span class="emoji">${b.emoji}</span><small>${b.name}</small></div>`).join("");
}
function weightedDrop(c){
 const pool=c.pool;
 const weights=pool.map(b=>rarities[b.rarity].weight);
 const total=weights.reduce((a,b)=>a+b,0);let n=Math.random()*total;
 for(let i=0;i<pool.length;i++){n-=weights[i];if(n<=0)return pool[i]}
 return pool[pool.length-1];
}
function openCase(){
 if(busy)return;if(state.coins<selectedCase.price){toast("Недостаточно монет!");return}
 busy=true;state.coins-=selectedCase.price;save();$("#open-one").disabled=true;$("#result").textContent="Ищем твоего брейнрота…";
 const winner=weightedDrop(selectedCase);const roulette=$("#roulette");
 const tiles=Array.from({length:25},(_,i)=>i===20?winner:selectedCase.pool[Math.floor(Math.random()*selectedCase.pool.length)]);
 roulette.innerHTML=tiles.map(b=>`<div class="tile" style="border-bottom:2px solid ${rarities[b.rarity].color}"><span class="emoji">${b.emoji}</span><small>${b.name}</small></div>`).join("");
 roulette.style.transition="none";roulette.style.transform="translateX(0)";void roulette.offsetWidth;
 const tileWidth=114;const target=20*tileWidth-(roulette.parentElement.clientWidth/2)+tileWidth/2;
 roulette.style.transition="transform 3.2s cubic-bezier(.08,.72,.08,1)";roulette.style.transform=`translateX(-${Math.max(0,target)}px)`;
 setTimeout(()=>{
  state.inventory[winner.name]??={...winner,count:0};state.inventory[winner.name].count++;
  state.history.unshift({name:winner.name,rarity:winner.rarity,case:selectedCase.name,date:Date.now()});state.history=state.history.slice(0,50);save();
  $("#result").innerHTML=`Выпало: <span style="color:${rarities[winner.rarity].color}">${winner.emoji} ${winner.name}</span> · ${winner.rarity}`;
  $("#open-one").disabled=false;busy=false;toast("Предмет добавлен в коллекцию!");
 },3250);
}
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300)}
$("#open-one").addEventListener("click",openCase);
$("#close-opener").addEventListener("click",()=>$("#opener").classList.add("hidden"));
$("#show-odds").addEventListener("click",()=>{
 const odds=$("#odds");odds.classList.toggle("hidden");
 odds.innerHTML=selectedCase.pool.map(b=>`<span style="border:1px solid ${rarities[b.rarity].color}55">${b.emoji} ${b.rarity}: ${((rarities[b.rarity].weight/selectedCase.pool.reduce((s,x)=>s+rarities[x.rarity].weight,0))*100).toFixed(1)}%</span>`).join("");
});
$("#reset").addEventListener("click",()=>{if(confirm("Сбросить баланс и коллекцию в демо?")){state={coins:1000,inventory:{},history:[],daily:null};save();toast("Демо сброшено")}});
renderCases();renderBalance();renderInventory();
