import { z } from "zod";

const Env = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().int().positive().default(3000),
  DATABASE_URL: z.string().min(1),
  TELEGRAM_BOT_TOKEN: z.string().default(""),
  SESSION_SECRET: z.string().min(32),
  WEB_ORIGIN: z.string().url().default("http://localhost:5173"),
  DEV_AUTH: z.enum(["true", "false"]).default("false"),
});
export const env = Env.parse(process.env);
if (env.NODE_ENV === "production" && (!env.TELEGRAM_BOT_TOKEN || env.DEV_AUTH === "true")) {
  throw new Error("Production requires TELEGRAM_BOT_TOKEN and DEV_AUTH=false");
}
