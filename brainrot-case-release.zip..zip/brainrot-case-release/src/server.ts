import Fastify from "fastify";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import { z } from "zod";
import { env } from "./config.js";
import { prisma } from "./prisma.js";
import { makeSession, requestUserId, telegramIdentity } from "./auth.js";

const app = Fastify({ logger: true, bodyLimit: 16_384 });
await app.register(helmet);
await app.register(cors, { origin: env.WEB_ORIGIN, credentials: false });
await app.register(rateLimit, { max: 60, timeWindow: "1 minute" });

const catalog = [
  { id:"common", title:"Обычный кейс", price:99, drops:[
    {itemKey:"duckolini",title:"Duckolini",emoji:"🦆",rarity:"COMMON",weight:60},
    {itemKey:"chimpanzini",title:"Chimpanzini Bananini",emoji:"🐒",rarity:"RARE",weight:30},
    {itemKey:"tungtung",title:"Tung Tung Tung Sahur",emoji:"🪵",rarity:"EPIC",weight:10}]},
  { id:"rare", title:"Редкий кейс", price:299, drops:[
    {itemKey:"lirilì",title:"Lirilì Larilà",emoji:"🐸",rarity:"RARE",weight:55},
    {itemKey:"ballerina",title:"Ballerina Cappuccina",emoji:"☕",rarity:"EPIC",weight:30},
    {itemKey:"tralalero",title:"Tralalero Tralala",emoji:"🦈",rarity:"LEGENDARY",weight:15}]},
  { id:"epic", title:"Эпический кейс", price:799, drops:[
    {itemKey:"ballerina",title:"Ballerina Cappuccina",emoji:"☕",rarity:"EPIC",weight:55},
    {itemKey:"bombardiro",title:"Bombardiro Crocodilo",emoji:"🐊",rarity:"LEGENDARY",weight:35},
    {itemKey:"tralalero",title:"Tralalero Tralala",emoji:"🦈",rarity:"MYTHIC",weight:10}]}
] as const;

async function getOrCreateUser(telegramId: string, username?: string | null, displayName?: string | null) {
  return prisma.user.upsert({
    where: { telegramId },
    update: { username: username ?? undefined, displayName: displayName ?? undefined },
    create: { telegramId, username: username ?? null, displayName: displayName ?? null, balance: 1250 }
  });
}
async function ensureDevUser(id: string) {
  return getOrCreateUser(id.replace("dev:", ""));
}
async function requireUser(req: any, reply: any) {
  const id = await requestUserId(req);
  if (!id) { reply.code(401).send({ error: "AUTH_REQUIRED" }); return null; }
  if (id.startsWith("dev:")) return ensureDevUser(id);
  return prisma.user.findUnique({ where: { id } });
}
function roll<T extends {weight:number}>(drops: readonly T[]): T {
  const total = drops.reduce((n,d)=>n+d.weight,0);
  let pick = Math.random()*total;
  for (const d of drops) { pick -= d.weight; if (pick < 0) return d; }
  return drops[drops.length-1]!;
}

app.get("/health", async () => ({ ok: true, service: "brainrot-case-api" }));
app.post("/api/v1/auth/telegram", async (req, reply) => {
  const body = z.object({ initData: z.string().min(1).max(10_000) }).safeParse(req.body);
  if (!body.success) return reply.code(400).send({ error: "INVALID_BODY" });
  try {
    const identity = await telegramIdentity(body.data.initData);
    const user = await getOrCreateUser(identity.telegramId, identity.username, identity.displayName);
    return { token: await makeSession(user.id), user: { id:user.id, username:user.username, balance:user.balance } };
  } catch (e) {
    req.log.warn({ err:e }, "Telegram auth failed");
    return reply.code(401).send({ error: "TELEGRAM_AUTH_FAILED" });
  }
});

app.get("/api/v1/cases", async () => catalog.map(({id,title,price,drops}) => ({
  id,title,price,drops:drops.map(({weight,...item})=>({...item,weight}))
})));

app.get("/api/v1/me", async (req, reply) => {
  const user = await requireUser(req, reply); if (!user) return;
  return { id:user.id, username:user.username, displayName:user.displayName, balance:user.balance };
});
app.get("/api/v1/inventory", async (req, reply) => {
  const user = await requireUser(req, reply); if (!user) return;
  return prisma.inventoryItem.findMany({ where:{userId:user.id}, orderBy:{createdAt:"desc"}, take:100 });
});

app.post("/api/v1/cases/:caseId/open", async (req, reply) => {
  const user = await requireUser(req, reply); if (!user) return;
  const params = z.object({caseId:z.string().min(1).max(40)}).safeParse(req.params);
  const body = z.object({idempotencyKey:z.string().uuid()}).safeParse(req.body);
  if (!params.success || !body.success) return reply.code(400).send({error:"INVALID_REQUEST"});
  const definition = catalog.find(c=>c.id===params.data.caseId);
  if (!definition) return reply.code(404).send({error:"CASE_NOT_FOUND"});
  try {
    const result = await prisma.$transaction(async tx => {
      const existing = await tx.caseOpening.findUnique({where:{userId_idempotencyKey:{userId:user.id,idempotencyKey:body.data.idempotencyKey}}, include:{awardedItem:true}});
      if (existing) return { opening:existing, balance:(await tx.user.findUniqueOrThrow({where:{id:user.id}})).balance, replay:true };
      const debit = await tx.user.updateMany({where:{id:user.id,balance:{gte:definition.price}},data:{balance:{decrement:definition.price}}});
      if (debit.count !== 1) throw new Error("INSUFFICIENT_BALANCE");
      const drop = roll(definition.drops);
      const item = await tx.inventoryItem.create({data:{userId:user.id,itemKey:drop.itemKey,title:drop.title,emoji:drop.emoji,rarity:drop.rarity}});
      const opening = await tx.caseOpening.create({data:{userId:user.id,caseId:definition.id,idempotencyKey:body.data.idempotencyKey,pricePaid:definition.price,awardedItemId:item.id},include:{awardedItem:true}});
      await tx.balanceTransaction.create({data:{userId:user.id,amount:-definition.price,kind:"CASE_OPEN",reference:opening.id}});
      const fresh = await tx.user.findUniqueOrThrow({where:{id:user.id}});
      return {opening,balance:fresh.balance,replay:false};
    }, { isolationLevel:"Serializable" });
    return { balance:result.balance, item:result.opening.awardedItem, replay:result.replay };
  } catch (e) {
    if (e instanceof Error && e.message==="INSUFFICIENT_BALANCE") return reply.code(409).send({error:"INSUFFICIENT_BALANCE"});
    req.log.error({err:e},"Case opening failed");
    return reply.code(500).send({error:"CASE_OPEN_FAILED"});
  }
});

app.post("/api/v1/daily-bonus/claim", async (req, reply) => {
  const user = await requireUser(req, reply); if (!user) return;
  const claimDate = new Date().toISOString().slice(0,10), amount = 250;
  try {
    const result = await prisma.$transaction(async tx => {
      await tx.dailyBonusClaim.create({data:{userId:user.id,claimDate,amount}});
      await tx.user.update({where:{id:user.id},data:{balance:{increment:amount}}});
      await tx.balanceTransaction.create({data:{userId:user.id,amount,kind:"DAILY_BONUS",reference:claimDate}});
      return tx.user.findUniqueOrThrow({where:{id:user.id}});
    });
    return {balance:result.balance,claimed:true};
  } catch {
    return reply.code(409).send({error:"BONUS_ALREADY_CLAIMED"});
  }
});

app.post("/api/v1/withdrawals", async (req, reply) => {
  const user = await requireUser(req, reply); if (!user) return;
  const body = z.object({inventoryItemId:z.string().min(1),robloxUsername:z.string().trim().min(3).max(20).regex(/^[A-Za-z0-9_]+$/)}).safeParse(req.body);
  if (!body.success) return reply.code(400).send({error:"INVALID_REQUEST"});
  const item = await prisma.inventoryItem.findFirst({where:{id:body.data.inventoryItemId,userId:user.id,status:"OWNED"}});
  if (!item) return reply.code(404).send({error:"ITEM_NOT_AVAILABLE"});
  // This only creates a review request. It does not transfer anything into the game.
  const request = await prisma.withdrawalRequest.create({data:{userId:user.id,inventoryItemId:item.id,robloxUsername:body.data.robloxUsername}});
  return reply.code(201).send({id:request.id,status:request.status,notice:"Pending manual review; no in-game transfer performed."});
});

app.setErrorHandler((error, req, reply) => {
  req.log.error(error);
  reply.code(500).send({error:"INTERNAL_SERVER_ERROR"});
});
const close = async () => { await app.close(); await prisma.$disconnect(); };
process.on("SIGINT", close); process.on("SIGTERM", close);
await app.listen({host:"0.0.0.0",port:env.PORT});
