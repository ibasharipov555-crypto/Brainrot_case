import { createHmac, timingSafeEqual } from "node:crypto";
import { SignJWT, jwtVerify } from "jose";
import type { FastifyRequest } from "fastify";
import { env } from "./config.js";

const secret = new TextEncoder().encode(env.SESSION_SECRET);

export async function telegramIdentity(initData: string) {
  if (!env.TELEGRAM_BOT_TOKEN) throw new Error("Telegram authentication is not configured");
  const params = new URLSearchParams(initData);
  const suppliedHash = params.get("hash");
  const authDate = Number(params.get("auth_date"));
  if (!suppliedHash || !Number.isFinite(authDate)) throw new Error("Invalid Telegram initData");
  if (Math.abs(Date.now() / 1000 - authDate) > 60 * 60 * 24) throw new Error("Expired Telegram initData");
  params.delete("hash");
  const checkString = [...params.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([k,v]) => `${k}=${v}`).join("\n");
  const secretKey = createHmac("sha256", "WebAppData").update(env.TELEGRAM_BOT_TOKEN).digest();
  const expected = createHmac("sha256", secretKey).update(checkString).digest("hex");
  const a = Buffer.from(expected, "hex"), b = Buffer.from(suppliedHash, "hex");
  if (a.length !== b.length || !timingSafeEqual(a, b)) throw new Error("Telegram signature mismatch");
  const rawUser = params.get("user");
  if (!rawUser) throw new Error("Telegram user missing");
  const user = JSON.parse(rawUser) as { id?: number; username?: string; first_name?: string };
  if (!user.id) throw new Error("Telegram user id missing");
  return { telegramId: String(user.id), username: user.username ?? null, displayName: user.first_name ?? null };
}

export async function makeSession(userId: string) {
  return new SignJWT({ sub: userId }).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("7d").sign(secret);
}

export async function requestUserId(req: FastifyRequest): Promise<string | null> {
  const auth = req.headers.authorization;
  if (auth?.startsWith("Bearer ")) {
    try {
      const { payload } = await jwtVerify(auth.slice(7), secret);
      return typeof payload.sub === "string" ? payload.sub : null;
    } catch { return null; }
  }
  if (env.NODE_ENV !== "production" && env.DEV_AUTH === "true") {
    const id = req.headers["x-dev-telegram-id"];
    if (typeof id === "string" && /^\d{1,20}$/.test(id)) return `dev:${id}`;
  }
  return null;
}
