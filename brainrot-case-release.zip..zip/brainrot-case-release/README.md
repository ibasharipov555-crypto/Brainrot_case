# Brainrot Case — server starter

Starter architecture for a shared web app + Telegram Mini App:
- TypeScript + Fastify API
- PostgreSQL + Prisma
- Telegram Mini App `initData` validation (HMAC, freshness check)
- Server-side balance updates and case rolls inside database transactions
- Idempotency key for case openings
- Docker Compose for local PostgreSQL
- Demo web client kept separate from the API

## Requirements
- Node.js 20+
- Docker Desktop (or a PostgreSQL 16 instance)
- Telegram bot token from BotFather for Mini App authentication

## Quick start
1. Copy `.env.example` to `.env`.
2. Set a strong `SESSION_SECRET` and your `TELEGRAM_BOT_TOKEN`.
3. Start the database: `docker compose up -d db`
4. Install and generate Prisma:
   ```bash
   npm install
   npm run db:generate
   npm run db:migrate
   npm run dev
   ```
5. Health check: `http://localhost:3000/health`

The API refuses to start in production without a Telegram bot token and strong session secret.
For local development only, set `DEV_AUTH=true` and use the demo header described below. Never enable this in production.

## API (v1)
- `GET /health` — health check
- `POST /api/v1/auth/telegram` — body `{ "initData": "..." }`; validates Telegram Web App init data and returns a signed session token
- `GET /api/v1/me` — current user and balance
- `GET /api/v1/cases` — public case catalog and prices
- `POST /api/v1/cases/:caseId/open` — body `{ "idempotencyKey": "UUID" }`; spends coins and awards a server-rolled item
- `GET /api/v1/inventory` — user's items
- `POST /api/v1/daily-bonus/claim` — one daily bonus per UTC date

For local-only testing with `DEV_AUTH=true`, send `x-dev-telegram-id: 123456789` instead of a bearer token. This path is explicitly disabled unless `NODE_ENV` is not `production`.

## Important security notes
- The browser never supplies a balance, price, drop table, rarity, or awarded item. Those are server-owned.
- A case opening uses a database transaction and an idempotency record to prevent duplicate charging/rewards on retries.
- Telegram `initData` must be sent raw to the server and validated there. Do not trust `initDataUnsafe` for identity.
- Put the API behind HTTPS in production; set CORS to your exact web origin.
- Add rate limiting, structured logs, backups, monitoring, and an admin workflow before public launch.
- Real-money payments are intentionally not implemented in this starter.
- Item withdrawal is a pending request workflow only. Do not promise transfer into Steal a Brainrot until a legitimate, authorized transfer mechanism is verified. Never ask users for Roblox passwords or session cookies.

## Deploying web + Telegram Mini App
Both clients use the same API. Host the web client on HTTPS and configure that URL in your bot's Mini App settings. Set `WEB_ORIGIN` to the exact web origin. The included `web/index.html` is a minimal API smoke-test page, not the final visual design.
